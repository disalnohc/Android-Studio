package com.example.shoppingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.firestore.FirebaseFirestore;

public class activity_login extends AppCompatActivity {
    EditText inemail , inpass;
    Button lgbtn;
    public static String login_result = "com.example.shoppingapp_RESULT";
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("B6401153 Login");

        inemail = findViewById(R.id.emaillg);
        inpass = findViewById(R.id.passwordlg);
        lgbtn = findViewById(R.id.lgbtn);

        mAuth = FirebaseAuth.getInstance();

        inemail.setText("123@gmail.com");
        inpass.setText("1234");

        lgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = inemail.getText().toString();
                String pass = inpass.getText().toString();
                Intent intent = new Intent(activity_login.this,activity_product.class);
                mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                            Toast.makeText(getApplicationContext(),"Login Success",Toast.LENGTH_LONG).show();
                            intent.putExtra(login_result,email);
                            startActivity(intent);
                    }
                });
            }
        });
    }
}