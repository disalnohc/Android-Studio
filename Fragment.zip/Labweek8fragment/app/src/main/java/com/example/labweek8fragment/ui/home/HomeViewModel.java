package com.example.labweek8fragment.ui.home;

import android.widget.ImageView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("เป็นซีรีส์มังงะญี่ปุ่น เขียนเรื่องและวาดภาพโดย ทัตสึยะ เอ็นโดะ เรื่องราวเกี่ยวกับสายลับผู้ \"สร้างครอบครัว\" เพื่อปฏิบัติภารกิจ โดยไม่ได้รู้ว่าเด็กหญิงที่รับเป็นบุตรสาวบุญธรรมเป็นผู้มีความสามารถในการอ่านใจ และผู้หญิงที่แต่งงานหลอก ๆ ด้วยเป็นมือสังหาร เผยแพร่ฟรีเป็นรายสองสัปดาห์ทางแอปพลิเคชันและเว็บไซต์โชเน็งจัมป์พลัสตั้งแต่วันที่ 25 มีนาคม พ.ศ. 2562 และรวบรวมตีพิมพ์เป็นหนังสือการ์ตูนรวมเล่ม (ทังโกบง) โดยสำนักพิมพ์ชูเอชะถึงเล่มที่ 10 เมื่อเดือนตุลาคม พ.ศ. 2565 มีลิขสิทธิ์ในประเทศไทยโดยสำนักพิมพ์สยามอินเตอร์คอมิกส์");
    }

    public LiveData<String> getText() {
        return mText;
    }
}