package com.example.shoppingapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class activity_product extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    EditText edname , edde;
    Button btnup;
    ImageView imca , imgal , imshow;
    TextView txemail;
    Uri mImgageUri;

    StorageReference reference;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        getSupportActionBar().setTitle("B6401153 Add Product");

        txemail = findViewById(R.id.textemail);
        btnup = findViewById(R.id.upbtn);
        imgal = findViewById(R.id.imgal);
        imca = findViewById(R.id.imca);
        imshow = findViewById(R.id.imshow);
        edname = findViewById(R.id.namepro);
        edde = findViewById(R.id.detailpro);

        reference = FirebaseStorage.getInstance().getReference("uploads");
        databaseReference = FirebaseDatabase.getInstance().getReference("uploads");
        Intent intent = getIntent();
        String email =intent.getStringExtra(activity_login.login_result);
        txemail.setText("Login by : " + email);

        imgal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  pictureChoose();
            }
        });

        btnup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadFile();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    private void pictureChoose() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    public void onlist(MenuItem menuItem) {
        Intent intent = new Intent(activity_product.this,activity_list.class);
        startActivity(intent);
    }

    public void onexit(MenuItem menuItem){
        Intent intent = new Intent(activity_product.this,MainActivity.class);
        startActivity(intent);
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {
        StorageReference fileReference = reference.child(System.currentTimeMillis()
        + "." + getFileExtension(mImgageUri));

        fileReference.putFile(mImgageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!urlTask.isSuccessful());
                        Uri downloadUrl = urlTask.getResult();

                        Upload upload = new Upload(edname.getText().toString().trim(),edde.getText().toString(),downloadUrl.toString());

                        String uploadId = databaseReference.push().getKey();
                        databaseReference.child(uploadId).setValue(upload);
                        Toast.makeText(getApplicationContext(),"Upload Success",Toast.LENGTH_LONG).show();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),"Failed to upload",Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            mImgageUri = data.getData();

            Picasso.with(this).load(mImgageUri).into(imshow);
        }
    }
}