package com.example.cashstatementapplication;

public class Model {
    String accname, money , descrip , date , type;

    public Model(String money, String descrip, String type, String date , String accname) {
        this.money = money;
        this.descrip = descrip;
        this.type = type;
        this.date = date;
        this.accname = accname;
    }

    public Model(){}

    public String getMoney() {
        return money;
    }
    public String getDescrip() {
        return descrip;
    }

    public String getDate() {
        return date;
    }

    public String getAccname() {
        return accname;
    }

    public String getType() {
        return type;
    }







}
