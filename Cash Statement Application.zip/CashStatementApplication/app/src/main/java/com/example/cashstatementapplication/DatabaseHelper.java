package com.example.cashstatementapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "Statement.db";
    private static final String DB_TABLE = "Statment_Table";
    private static final String DB_TABLEACC = "ACCOUNT";
    private static final String DB_HIS = "HISTORY_STATEMENT";
    private static final String ID = "ID";
    private static final String MONEY = "MOENY";
    private static final String ACCOUNT_NAME = "ACC_NAME";
    private static final String DESCRIPTION = "DESCRIPTION";
    private static final String DATE = "DATE";
    private static final String TYPESTATE = "TYPESTATE";
    private static final String MONTH = "MONTH";
    private static final String YEAR = "YEAR";
    private static final String INCOME = "INCOME";
    private static final String EXPENSES = "EXPENSES";

    private static final String CREATE_TABLE = "CREATE TABLE " + DB_TABLE + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            MONEY + " TEXT, " + DESCRIPTION + " TEXT, " +
            TYPESTATE + " TEXT," + DATE + " TEXT, " +
            ACCOUNT_NAME + " TEXT " + " )";

    private static final String CREATE_TABLE2 = "CREATE TABLE " + DB_TABLEACC + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            ACCOUNT_NAME + " TEXT, " +
            MONEY + " TEXT " + " )";

    private static final String CREATE_TABLE3 = "CREATE TABLE " + DB_HIS + " (" +
            ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            MONTH + " TEXT, " +
            YEAR + " TEXT, " +
            INCOME + " TEXT, " +
            EXPENSES + " TEXT )";


    public DatabaseHelper(Context context) {
        super(context,DB_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE2);
        db.execSQL(CREATE_TABLE3);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    db.execSQL("DROP TABLE IF EXISTS " + DB_TABLE);
    db.execSQL("DROP TABLE IF EXISTS " + DB_TABLEACC);
    db.execSQL("DROP TABLE IF EXISTS " + DB_HIS);
    onCreate(db);
    }

    public boolean insertData(String money , String descrip , String typestate , String stdate , String account) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MONEY , money);
        contentValues.put(DESCRIPTION , descrip);
        contentValues.put(TYPESTATE , typestate);
        contentValues.put(DATE, stdate);
        contentValues.put(ACCOUNT_NAME , account);

        long result = db.insert(DB_TABLE , null , contentValues);
        return result != -1;
    }

    public boolean insertAcc(String acc_name , String money) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ACCOUNT_NAME , acc_name);
        contentValues.put(MONEY, money);

        long result = db.insert(DB_TABLEACC , null , contentValues);
        return result != -1;
    }

    public boolean insertHis(String month , String year , String income , String expenses) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MONTH, month);
        contentValues.put(YEAR, year);
        contentValues.put(INCOME , income);
        contentValues.put(EXPENSES , expenses);

        long result = db.insert(DB_HIS,null,contentValues);
        return result != -1;
    }

    public Cursor viewData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * From " + DB_TABLE;
        Cursor cursor = db.rawQuery(query,null);

        return cursor;
    }

    public Cursor viewData2() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * From " + DB_TABLE + " ORDER BY " + DATE + " DESC";
        Cursor cursor = db.rawQuery(query,null);

        return cursor;
    }


    public Cursor hisintop() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * From " + DB_HIS + " ORDER BY " + ID + " DESC" + " LIMIT 1 ";
        Cursor cursor = db.rawQuery(query,null);
        return cursor;
    }

    public Cursor viewHis() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * From " + DB_HIS + " ORDER BY " + ID + " DESC";
        Cursor cursor = db.rawQuery(query,null);

        return cursor;
    }

    public Cursor viewAcc() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * From " + DB_TABLEACC;
        Cursor cursor = db.rawQuery(query,null);

        return cursor;
    }

    public boolean updateData(String accname , String money){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ACCOUNT_NAME,accname);
        values.put(MONEY,money);

        long result = db.update(DB_TABLEACC,values,ACCOUNT_NAME + " = '" + accname + "'",null);
        return  result != -1;
    }

    public ArrayList<Model> getAllData(){
        ArrayList<Model> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + DB_TABLE,null);

        while (cursor.moveToNext()){
            String money = cursor.getString(1);
            String des = cursor.getString(2);
            String type = cursor.getString(3);
            String date = cursor.getString(4);
            String acc = cursor.getString(5);

            Model model = new Model(money,des,type,date,acc);

            arrayList.add(model);

        }
        return arrayList;
    }

}
