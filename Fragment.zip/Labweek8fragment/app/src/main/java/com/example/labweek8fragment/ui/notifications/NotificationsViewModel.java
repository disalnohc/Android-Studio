package com.example.labweek8fragment.ui.notifications;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class NotificationsViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public NotificationsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("นินจาคาถาโอ้โฮเฮะ (ญี่ปุ่น: ナルト; โรมาจิ: Naruto) เป็นการ์ตูนญี่ปุ่น เนื้อหาเกี่ยวกับนินจา เรื่องและภาพโดยมาซาชิ คิชิโมโตะ ตีพิมพ์ครั้งแรกในปี พ.ศ. 2542 ลงในนิตยสาร 'โชเน็งจัมป์' ในประเทศญี่ปุ่น โดยมีโครงเรื่องเดิมมาจากผลงานที่คิชิโมโตะเคยเสนอให้สำนักพิมพ์ในปี 2540 ซึ่งต่อมาได้ถูกสร้างเป็น อนิเมะ และ เกม หลายต่อหลายภาค");
    }

    public LiveData<String> getText() {
        return mText;
    }
}