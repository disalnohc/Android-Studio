package com.example.touch.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.motion.widget.OnSwipe;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainer;
import androidx.lifecycle.ViewModelProvider;

import com.example.touch.R;
import com.example.touch.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment implements View.OnTouchListener,View.OnLongClickListener{

    private FragmentHomeBinding binding;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        binding.textOt.setText("Single touch pointer status data.");

        ConstraintLayout constraintLayout = (ConstraintLayout)root.findViewById(R.id.fmh);
        constraintLayout.setOnTouchListener(this);


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public boolean onLongClick(View v) {
        Toast.makeText(getActivity(), "Work", Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {



       binding.textOt.setText("");

       int totalpointer = event.getPointerCount();

        for(int i = 0;i<totalpointer;i++){
            StringBuffer pointerStatusBuf = new StringBuffer();
            int pointid = event.getPointerId(i);
            pointerStatusBuf.append("Pointer Id :");
            pointerStatusBuf.append(String.valueOf(i) + " . Action : ");
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN){
                pointerStatusBuf.append("Down. ");
            } else if (action == MotionEvent.ACTION_UP) {
                pointerStatusBuf.append("Up.");
            } else if (action == MotionEvent.ACTION_POINTER_DOWN) {
                pointerStatusBuf.append("Pointer Down.");
            } else if (action == MotionEvent.ACTION_POINTER_UP) {
                pointerStatusBuf.append("Pointer Up.");
            } else if (action == MotionEvent.ACTION_MOVE) {
                pointerStatusBuf.append("Move.");
            }

            int actionindex = event.getActionIndex();
            pointerStatusBuf.append("Action Index : ");
            pointerStatusBuf.append(String.valueOf(actionindex) + " . ");
            float x = event.getX(i);
            float y = event.getY(i);
            pointerStatusBuf.append("X : " + x);
            pointerStatusBuf.append(" , Y : " + y);

            if(pointid == 0) {
                binding.textOt.setText(pointerStatusBuf.toString());
            }
        }




        return true;
    }


}