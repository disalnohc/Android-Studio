package com.example.cashstatementapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class activity_account extends AppCompatActivity {

    AlertDialog dialog;
    EditText nameacc , monaccst;
    Button addacc , cancel;
    DatabaseHelper db;
    ListView list_acc;
    ArrayList<String> listItem;
    ArrayAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        getSupportActionBar().hide();

        AlertDialog.Builder builder = new AlertDialog.Builder(activity_account.this);
        builder.setTitle("");

        View view = getLayoutInflater().inflate(R.layout.fragment_account_dialog, null);
        FloatingActionButton fab = findViewById(R.id.fab_btn);

        listItem = new ArrayList<>();

        nameacc = view.findViewById(R.id.nameacc);
        monaccst = view.findViewById(R.id.monaccst);

        addacc = view.findViewById(R.id.addacc);
        cancel = view.findViewById(R.id.cancel);

        list_acc = findViewById(R.id.list_item);

        builder.setView(view);
        dialog = builder.create();

        db = new DatabaseHelper(activity_account.this);

        viewAcc();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dialog.dismiss();
                } catch (Exception e) {

                }
            }
        });

        addacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String acc_name = nameacc.getText().toString();
                    String money = monaccst.getText().toString();

                    if(!acc_name.equals("") && !money.equals("") && db.insertAcc(acc_name, money)) {
                        nameacc.setText("");
                        monaccst.setText("");

                        String eddate = "";
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            eddate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                        }

                        String descrip = "Add New Account";
                        String typestate = "Income";
                        String stdate = eddate;


                        if(!money.equals("") && !acc_name.equals("") && db.insertData(money,descrip,typestate,stdate,acc_name)){
                            Toast.makeText(activity_account.this,getString(R.string.succaddacc),Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(activity_account.this,getString(R.string.failaddacc), Toast.LENGTH_LONG).show();
                    }
                    listItem.clear();
                    viewAcc();
                } catch (Exception e) {
                }
            }
        });

    }

    void viewAcc() {
        Cursor cursor = db.viewAcc();

        if (cursor.getCount() == 0) {
            Toast.makeText(this, getString(R.string.plsaddacc), Toast.LENGTH_LONG).show();
        } else {
                while (cursor.moveToNext()) {
                    listItem.add(cursor.getString(1) + " : " + cursor.getString(2) + " ฿");
            }
                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItem);
                list_acc.setAdapter(adapter);
            }

        }



    public void openHome(View view) {
        try {
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,"Error", Toast.LENGTH_LONG).show();
        }
    }

    public void openSetting(View view) {
        try {
            Intent intent = new Intent(this,activity_setting.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,"Error", Toast.LENGTH_LONG).show();
        }
    }
}