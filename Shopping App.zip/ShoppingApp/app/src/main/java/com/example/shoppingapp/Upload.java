package com.example.shoppingapp;

public class Upload {
    String imname;
    String imde;
    String imuri;

    public Upload(){
        //empty constructor needed

    }
    public Upload(String name, String details , String picuri) {
        imname = name;
        imde = details;
        imuri = picuri;
    }

    public String getName() {
        return imname;
    }

    public void setName(String name) {
        imname = name;
    }

    public String getDetails(){ return imde;}

    public void setDetails(String details) {
        imde = details;
    }

    public String getImageUrl() {
        return imuri;
    }

    public void setImageUrl(String picuri) {
        imuri = picuri;
    }
}
