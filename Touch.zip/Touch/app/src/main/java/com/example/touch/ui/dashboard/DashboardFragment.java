package com.example.touch.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.touch.R;
import com.example.touch.databinding.FragmentDashboardBinding;

public class DashboardFragment extends Fragment implements View.OnTouchListener,View.OnLongClickListener{

    private FragmentDashboardBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DashboardViewModel dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);


        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        binding.textMt.setText("Single touch pointer status data.");
        binding.textMt2.setText("Multi touch pointer status data.");

        final TextView textView = binding.textDashboard;
        dashboardViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        ConstraintLayout constraintLayout = (ConstraintLayout)root.findViewById(R.id.fmd);
        constraintLayout.setOnTouchListener(this);

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public boolean onLongClick(View v) {
        return false;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        binding.textMt.setText("");

        int totalpointer = event.getPointerCount();

        for(int i = 0;i<totalpointer;i++){
            StringBuffer pointerStatusBuf = new StringBuffer();
            int pointid = event.getPointerId(i);
            pointerStatusBuf.append("Pointer Id :");
            pointerStatusBuf.append(String.valueOf(i) + " . Action : ");
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN){
                pointerStatusBuf.append("Down. ");
            } else if (action == MotionEvent.ACTION_UP) {
                pointerStatusBuf.append("Up.");
            } else if (action == MotionEvent.ACTION_POINTER_DOWN) {
                pointerStatusBuf.append("Pointer Down.");
            } else if (action == MotionEvent.ACTION_POINTER_UP) {
                pointerStatusBuf.append("Pointer Up.");
            } else if (action == MotionEvent.ACTION_MOVE) {
                pointerStatusBuf.append("Move.");
            }

            int actionindex = event.getActionIndex();
            pointerStatusBuf.append("Action Index : ");
            pointerStatusBuf.append(String.valueOf(actionindex) + " . ");
            float x = event.getX(i);
            float y = event.getY(i);
            pointerStatusBuf.append("X : " + x);
            pointerStatusBuf.append(" , Y : " + y);

            if(pointid == 0) {
                binding.textMt.setText(pointerStatusBuf.toString());
            } else {
                binding.textMt2.setText(pointerStatusBuf.toString());
            }
        }

        return true;
    }
}