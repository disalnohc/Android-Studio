package com.example.cashstatementapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    AlertDialog dialog , dialog2 , dialog3;
    Button btnin , btnclose , bal_close , btn_his , his_close;
    EditText eMon , eDes , eDate;
    ListView cashview , acc_delist , his_list;
    ArrayList<Model> listItem;
    ArrayList<String> listacc , listacde , listhis;
    ArrayAdapter adapter;
    Spinner spintype , spinac1 , spinac2;
    TextView textac , txtsumall , txtplus , txtminus , bal_accde , bal_bal;
    MyAdapter myAdapter;
    private int year, month, day;

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        String date = "";
        String eddate = "";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            eddate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        }

        TextView textView3 = (TextView) findViewById(R.id.date);
        textView3.setText(date.toString());
        textView3.setTextSize(36);


        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("");

        AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
        builder2.setTitle("");

        AlertDialog.Builder builder3 = new AlertDialog.Builder(MainActivity.this);
        builder3.setTitle("");

        View view2 = getLayoutInflater().inflate(R.layout.fragment_acc_btn,null);

        View view = getLayoutInflater().inflate(R.layout.fragment_income_dialog, null);

        View view3 = getLayoutInflater().inflate(R.layout.fragment_his_btn,null);
        FloatingActionButton fab = findViewById(R.id.fab_btn);
        // DATABASE
        db = new DatabaseHelper(MainActivity.this);
        // ARRAY
        listItem = new ArrayList<>();
        listacc = new ArrayList<>();
        listacde = new ArrayList<>();
        listhis = new ArrayList<>();

        spintype = view.findViewById(R.id.spinner);
        spinac1 = view.findViewById(R.id.spinac1);
        spinac2 = view.findViewById(R.id.spinac2);
        textac = view.findViewById(R.id.txtac);

        spinac1.setVisibility(View.GONE);
        spinac2.setVisibility(View.GONE);
        textac.setVisibility(View.GONE);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.type_statement, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spintype.setAdapter(adapter);

        btnin = view.findViewById(R.id.btnin);
        btnclose = view.findViewById(R.id.btnclose);
        eMon = view.findViewById(R.id.eMon);
        eDes = view.findViewById(R.id.eDes);
        eDate = view.findViewById(R.id.datetext);
        cashview = findViewById(R.id.liststm);
        eDate.setText(eddate.toString());

        txtsumall = findViewById(R.id.sumall);
        txtplus = findViewById(R.id.sumplus);
        txtminus = findViewById(R.id.summinus);

        bal_close = view2.findViewById(R.id.bal_close);
        bal_accde = view2.findViewById(R.id.txtacde);
        bal_bal = view2.findViewById(R.id.txtbal);
        acc_delist = view2.findViewById(R.id.acc_list);

        btn_his = findViewById(R.id.his_btn);
        his_close = view3.findViewById(R.id.his_close);
        his_list = view3.findViewById(R.id.his_list);

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayofmonth = calendar.get(Calendar.DAY_OF_MONTH);


        //Calender Select
        eDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();

                int currentYear = calendar.get(Calendar.YEAR);
                int currentMonth = calendar.get(Calendar.MONTH);
                int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        String dday = "";
                        String mmonth = "";
                        if (String.valueOf(day).length() <2){
                            dday = "0"+String.valueOf(day);
                        } else {
                            dday = String.valueOf(day);
                        }

                        month = month + 1;

                        if (String.valueOf(month).length() <2){
                            mmonth = "0"+String.valueOf(month);
                        } else {
                            mmonth = String.valueOf(month);
                        }

                        String cd = dday+"/"+String.valueOf(mmonth)+"/"+String.valueOf(year);
                        eDate.setText(cd);
                    }
                };

                long maxTime = calendar.getTimeInMillis();

                calendar.set(Calendar.DAY_OF_MONTH, 1);

                long minTime = calendar.getTimeInMillis();

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        MainActivity.this,
                        listener,
                        currentYear,
                        currentMonth,
                        currentDay
                );

                datePickerDialog.getDatePicker().setMaxDate(maxTime);
                datePickerDialog.getDatePicker().setMinDate(minTime);

                datePickerDialog.show();
            }
        });

        viewData();
        loadaccount();
        setAcc_delist();


        int id = (int) spintype.getSelectedItemId();
        // hide spinner
        spintype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long id) {
                if(id == 2) {
                    spinac1.setVisibility(View.VISIBLE);
                    spinac2.setVisibility(View.VISIBLE);
                    textac.setVisibility(View.VISIBLE);
                    eDes.setVisibility(View.GONE);
                } else  {
                    spinac1.setVisibility(View.VISIBLE);
                    spinac2.setVisibility(View.GONE);
                    textac.setVisibility(View.GONE);
                    eDes.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Insert Data
        btnin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String money = eMon.getText().toString();
                    String descrip = eDes.getText().toString();
                    String stdate = eDate.getText().toString();
                    String account = (String) spinac1.getSelectedItem();
                    String account2 = (String) spinac2.getSelectedItem();
                    String typestate = "";
                    int tid = (int) spintype.getSelectedItemId();



                    if(!money.equals("") && !stdate.equals("") && !account.equals("")) {

                        switch (tid){
                            case 0:
                                typestate = "Income";
                                break;
                            case 1:
                                typestate = "Expenses";
                                break;
                            case 2:
                                typestate = "Transfer";
                                break;
                        }

                        if(!descrip.equals("")) {
                            // do something in here
                            if(updateDataTest() == true) {
                                db.insertData(money,descrip,typestate,stdate,account);
                                Toast.makeText(MainActivity.this,R.string.addstatement, Toast.LENGTH_LONG).show();
                                setAcc_delist();
                            } else {
                                Toast.makeText(MainActivity.this, getString(R.string.moneynotenough), Toast.LENGTH_SHORT).show();
                                setAcc_delist();
                            }
                        } else if (typestate.equals("Transfer")){
                            descrip = "Transfer " + account + " to " + account2;
                            // do something in here

                            if(!account.equals(account2)) {
                                if(updateDataTran() == true) {
                                    db.insertData(money,descrip,typestate,stdate,account);
                                    Toast.makeText(MainActivity.this,getString(R.string.addstatement), Toast.LENGTH_LONG).show();
                                    setAcc_delist();
                                } else {
                                    Toast.makeText(MainActivity.this, getString(R.string.moneynotenough), Toast.LENGTH_SHORT).show();
                                    setAcc_delist();
                                }
                            } else {
                                Toast.makeText(MainActivity.this, getString(R.string.cannottrans), Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            descrip = "No Description";
                            // do something in here
                            if(updateDataTest() == true) {
                                db.insertData(money,descrip,typestate,stdate,account);
                                Toast.makeText(MainActivity.this,getString(R.string.addstatement), Toast.LENGTH_LONG).show();
                                setAcc_delist();
                            } else {
                                Toast.makeText(MainActivity.this, getString(R.string.moneynotenough), Toast.LENGTH_SHORT).show();
                                setAcc_delist();
                            }

                        }
                        eMon.setText("");
                        eDes.setText("");


                    } else {
                        Toast.makeText(MainActivity.this,getString(R.string.failstatement), Toast.LENGTH_LONG).show();
                    }
                    // end add data
                    listItem.clear();
                    viewData();
                    calculate();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,getString(R.string.failstatement), Toast.LENGTH_LONG).show();
                }
            }
        });

        btnclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    dialog.dismiss();
                }catch (Exception e) {
                }
            }
        });

        bal_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog2.dismiss();
            }
        });

        builder.setView(view);
        dialog = builder.create();

        builder2.setView(view2);
        dialog2 = builder2.create();

        builder3.setView(view3);
        dialog3 = builder3.create();

        txtsumall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog2.show();
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();
            }
        });

        btn_his.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog3.show();
            }
        });

        his_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog3.dismiss();
            }
        });

        // Check Date to Upload History
        calculate();
        updateHis(eddate);
        loadhistory();
    }

    private void loadhistory() {
        Cursor cursor = db.viewHis();

        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                if (!cursor.getString(0).equals("1")){
                    int mid = Integer.parseInt(cursor.getString(1));

                    String month = "";

                    switch (mid){
                        case 1:
                            month = getString(R.string.jan);
                            break;
                        case 2:
                            month = getString(R.string.feb);
                            break;
                        case 3:
                            month = getString(R.string.mar);
                            break;
                        case 4:
                            month = getString(R.string.apr);
                            break;
                        case 5:
                            month = getString(R.string.may);
                            break;
                        case 6:
                            month = getString(R.string.jun);
                            break;
                        case 7:
                            month = getString(R.string.jul);
                            break;
                        case 8:
                            month = getString(R.string.aug);
                            break;
                        case 9:
                            month = getString(R.string.sept);
                            break;
                        case 10:
                            month = getString(R.string.oct);
                            break;
                        case 11:
                            month = getString(R.string.nov);
                            break;
                        case 12:
                            month = getString(R.string.dec);
                            break;
                    }
                    String in = getString(R.string.inc)+" "+cursor.getString(3)+" ฿";
                    String ex = getString(R.string.ex)+" "+cursor.getString(4)+" ฿";

                    listhis.add(month+" "+cursor.getString(2)+" \n"+in+" : "+ex);
                }
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,listhis);
            his_list.setAdapter(adapter);
        }
    }

    private void updateHis(String eddate) {
        try {
            Cursor cursor = db.viewHis();
            Cursor lasthis = db.hisintop();
            String month,year,income,expenses;
            month = String.valueOf(eddate.charAt(3)).concat(String.valueOf(eddate.charAt(4)));
            year = String.valueOf(eddate.charAt(6)).concat(String.valueOf(eddate.charAt(7))).concat(String.valueOf(eddate.charAt(8))).concat(String.valueOf(eddate.charAt(9)));
            Double sumplus = 0.0 , summinus = 0.0;

            if (cursor.getCount() == 0) {
                if(Integer.valueOf(month) - 1 != 0){
                    month = String.valueOf(Integer.valueOf(month) -1);
                    income = "0";
                    expenses = "0";
                    db.insertHis("0"+month,year,income,expenses);
                } else {
                    month = "12";
                    year = String.valueOf(Integer.valueOf(year) -1);
                    income = "0";
                    expenses = "0";
                    db.insertHis(month,year,income,expenses);
                }
                Toast.makeText(this, getString(R.string.firstin), Toast.LENGTH_SHORT).show();
            } else {
                cursor.moveToNext();
                String dbdate = cursor.getString(1)+"/"+cursor.getString(2);

                if (!(month+"/"+year).equals(dbdate)) {
                    //
                    Cursor cursor1 = db.viewData2();
                    if (cursor1.getCount() != 0){
                        if (Integer.valueOf(month)-1 != 0) {
                            month = String.valueOf(Integer.valueOf(month) - 1);
                            String date = "0" + month + "/" + year;
                            while (cursor1.moveToNext()) {
                                if (cursor1.getString(4).substring(3).equals(date)) {
                                    if (cursor1.getString(3).equals("Income")) {
                                        if (!cursor1.getString(2).equals("Add New Account")) {
                                            sumplus = sumplus + Double.valueOf(cursor1.getString(1));
                                        }
                                    } else if (cursor1.getString(3).equals("Expenses")) {
                                        summinus = summinus + Double.valueOf(cursor1.getString(1));
                                    }
                                }
                            }
                            lasthis.moveToNext();
                            String lhdate = lasthis.getString(1)+"/"+lasthis.getString(2);
                            if(!lhdate.equals(date)){
                                if (db.insertHis("0"+month,year,String.valueOf(sumplus),String.valueOf(summinus))){
                                    Toast.makeText(this, getString(R.string.suchis), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }else {
                            month = "12";
                            year = String.valueOf(Integer.valueOf(year) - 1);
                            String date = month+"/"+year;
                            while (cursor1.moveToNext()){
                                if (cursor1.getString(4).substring(3).equals(date)){
                                    if(cursor1.getString(3).equals("Income")) {
                                        if(!cursor1.getString(2).equals("Add New Account")){
                                            sumplus = sumplus + Double.valueOf(cursor1.getString(1));
                                        }
                                    } else if (cursor1.getString(3).equals("Expenses")){
                                        summinus = summinus + Double.valueOf(cursor1.getString(1));
                                    }
                                }
                            }
                            lasthis.moveToNext();
                            String lhdate = lasthis.getString(1)+"/"+lasthis.getString(2);
                            if(!lhdate.equals(date)){
                                if (db.insertHis(month,year,String.valueOf(sumplus),String.valueOf(summinus))){
                                    Toast.makeText(this, getString(R.string.suchis), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                    //
                }
                }

        }catch (Exception e){

        }
    }


    private boolean updateDataTran() {
        boolean result = true;
        boolean check = false;
        try {
            Cursor cursor = db.viewAcc();
            String accname = (String) spinac1.getSelectedItem();
            String accname2 = (String) spinac2.getSelectedItem();
            String money = eMon.getText().toString();
            String typestate = "";
            int tid = (int) spintype.getSelectedItemId();

            txtsumall.setText(getString(R.string.sum));
            txtplus.setText(getString(R.string.income));
            txtminus.setText(getString(R.string.expen));

            while (cursor.moveToNext()){

                switch (tid){
                    case 0:
                        typestate = "Income";
                        break;
                    case 1:
                        typestate = "Expenses";
                        break;
                    case 2:
                        typestate = "Transfer";
                        break;
                }

                if (typestate.equals("Transfer")){
                        if(cursor.getString(1).equals(accname)){
                            double kpmoney = Double.valueOf(cursor.getString(2));
                            kpmoney = kpmoney - Double.valueOf(money);
                            if(kpmoney >= 0) {
                                db.updateData(accname,String.valueOf(kpmoney));
                                check = true;
                            } else if (kpmoney <= 0) {result = false; check = false;}
                        } else if (check == true) {
                            if (cursor.getString(1).equals(accname2)){
                                double kpmoney = Double.valueOf(cursor.getString(2));
                                kpmoney = kpmoney + Double.valueOf(money);
                                db.updateData(accname2,String.valueOf(kpmoney));
                                result = true;
                            }
                        }
                }
            }
        }catch (Exception e){
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    private void viewData() {
        listItem = db.getAllData();
        myAdapter = new MyAdapter(this,listItem);
        cashview.setAdapter(myAdapter);
        myAdapter.notifyDataSetChanged();
        Collections.reverse(listItem);
    }

    public void openAccount(View view) {
        try {
            Intent intent = new Intent(this,activity_account.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,"Error", Toast.LENGTH_LONG).show();
        }
    }

    public void openSetting(View view) {
        try {
            Intent intent = new Intent(this,activity_setting.class);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,"Error", Toast.LENGTH_LONG).show();
        }
    }

    private void loadaccount(){
        Cursor cursor = db.viewAcc();
        if (cursor.getCount() == 0) {
        } else {
            while (cursor.moveToNext()) {
                listacc.add(cursor.getString(1));
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1 , listacc);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinac1.setAdapter(adapter);
            spinac2.setAdapter(adapter);
        }
    }

    private boolean updateDataTest(){
        boolean result = true;
        try {
            Cursor cursor = db.viewAcc();
            String accname = (String) spinac1.getSelectedItem();
            String accname2 = (String) spinac2.getSelectedItem();
            String money = eMon.getText().toString();
            String typestate = "";
            int tid = (int) spintype.getSelectedItemId();

            txtsumall.setText(getString(R.string.sum));
            txtplus.setText(getString(R.string.income));
            txtminus.setText(getString(R.string.expen));

            while (cursor.moveToNext()){

                switch (tid){
                    case 0:
                        typestate = "Income";
                        break;
                    case 1:
                        typestate = "Expenses";
                        break;
                    case 2:
                        typestate = "Transfer";
                        break;
                }

                if(cursor.getString(1).equals(accname)){
                    // Expen
                    if (typestate.equals("Expenses")){
                        double kpmoney = Double.valueOf(cursor.getString(2));
                        kpmoney = kpmoney - Double.valueOf(money);
                        if(kpmoney >= 0) {
                            db.updateData(accname,String.valueOf(kpmoney));
                        } else if (kpmoney <= 0) {result = false;}
                    }
                    // Income
                    else if (typestate.equals("Income")){
                        double kpmoney = Double.valueOf(cursor.getString(2));
                        kpmoney = kpmoney + Double.valueOf(money);
                        db.updateData(accname,String.valueOf(kpmoney));
                        result = true;
                    }
                }
            }

        } catch (Exception e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    private void calculate(){
        Cursor cursor = db.viewData();
        String eddate = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            eddate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        }

        double sumplus = 0;
        double summinus = 0;
        double sum = 0;
        if (cursor.getCount() == 0) {
            txtsumall.setText(getString(R.string.sum));
            txtplus.setText(getString(R.string.income));
            txtminus.setText(getString(R.string.expen));
        } else {
            while (cursor.moveToNext()) {
                if (cursor.getString(4).substring(3).equals(eddate.substring(3))){
                    if(cursor.getString(3).equals("Income")) {
                        if(!cursor.getString(2).equals("Add New Account")){
                            sumplus = sumplus + Double.valueOf(cursor.getString(1));
                            txtplus.setText(getString(R.string.inc) + " " + String.valueOf(sumplus) + " ฿");
                        }
                    } else if (cursor.getString(3).equals("Expenses")){
                        summinus = summinus + Double.valueOf(cursor.getString(1));
                        txtminus.setText(getString(R.string.ex) + " " +String.valueOf(summinus) + " ฿");
                    }
                }
            }
        }
    }

    void setAcc_delist() {
        Cursor cursor = db.viewAcc();
        listacde.clear();
        double sum = 0;
            while (cursor.moveToNext()) {
                listacde.add(cursor.getString(1) + " : " + cursor.getString(2) + " ฿");
                sum = sum + Double.valueOf(cursor.getString(2));
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listacde);
            acc_delist.setAdapter(adapter);
            bal_bal.setText(getString(R.string.bal) + " : " +String.valueOf(sum) + " ฿");
            txtsumall.setText(getString(R.string.bal) + " : " +String.valueOf(sum) + " ฿");

    }

    private void setupUi() {
        // Get calendar instance
        Calendar calendar = Calendar.getInstance();

        // Get current time
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

        View view = getLayoutInflater().inflate(R.layout.fragment_income_dialog, null);

        eDate = view.findViewById(R.id.datetext);

        // Create listener
        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                // Show Toast after selection
                String cd = String.valueOf(day)+"/"+String.valueOf(month)+"/"+String.valueOf(year);
                Toast.makeText(MainActivity.this, String.format("Selected : " + cd ), Toast.LENGTH_SHORT).show();
                eDate.setText(cd);
            }
        };

        // Max = current
        long maxTime = calendar.getTimeInMillis();

        // Move day as first day of the month
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        // Move "month" for previous one
//        calendar.add(Calendar.MONTH, -1);

        // Min = time after changes
        long minTime = calendar.getTimeInMillis();

        // Create dialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                listener,
                currentYear,
                currentMonth,
                currentDay
        );

        // Set dates
        datePickerDialog.getDatePicker().setMaxDate(maxTime);
        datePickerDialog.getDatePicker().setMinDate(minTime);

        // Show dialog
        datePickerDialog.show();
    }
}