package com.example.labweek8fragment.ui.dashboard;

import android.widget.ImageView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DashboardViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public DashboardViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("ดาบพิฆาตอสูร (ญี่ปุ่น: 鬼滅の刃; โรมาจิ: Kimetsu no Yaiba; ทับศัพท์: คิเม็ตสึ โนะ ไยบะ) เป็นซีรีส์หนังสือการ์ตูนของประเทศญี่ปุ่น เขียนเรื่องโดย โคโยฮารุ โกโตเกะ เนื้อหากล่าวถึงคามาโดะ ทันจิโร่ เด็กหนุ่มผู้กลายเป็นนักล่าอสูรหลังจากครอบครัวของตนถูกอสูรฆ่าตายทั้งหมด ยกเว้นเพียงน้องสาวที่ชื่อเนะซึโกะเท่านั้นที่ได้กลายเป็นอสูรไป เขาจึงตั้งปณิธานว่าจะหาทางทำให้น้องสาวกลับมาเป็นมนุษย์ดังเดิมให้ได้");

    }

    public LiveData<String> getText() {
        return mText;
    }
}