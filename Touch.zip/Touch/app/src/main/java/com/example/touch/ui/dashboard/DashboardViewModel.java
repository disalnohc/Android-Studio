package com.example.touch.ui.dashboard;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DashboardViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    public DashboardViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Value of position (x,y)");
    }

    public LiveData<String> getText() {
        return mText;
    }
}