package com.example.cashstatementapplication;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    Context context;
    ArrayList<Model> arrayList;

    public MyAdapter(Context context,ArrayList<Model> arrayList){
        this.context=context;
        this.arrayList = arrayList;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {



            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.card_view,null);

            TextView txacc = (TextView)convertView.findViewById(R.id.card_acctext);
            TextView txda = (TextView)convertView.findViewById(R.id.card_daytext);
            TextView txty = (TextView)convertView.findViewById(R.id.card_type);
            TextView txdes = (TextView)convertView.findViewById(R.id.card_des);
            TextView txmon = (TextView)convertView.findViewById(R.id.card_amount);

            Model model = arrayList.get(position);

            txacc.setText(model.getAccname());
            txda.setText(model.getDate()); // date
            txty.setText(model.getType());
            txty.setVisibility(View.GONE);
            txdes.setText(model.getDescrip());
            if(model.getType().equals("Income")){
                txmon.setText(" + " + model.getMoney() + " ฿");
                txmon.setTextColor(Color.GREEN);
            } else if(model.type.equals("Expenses")){
                txmon.setText(" - " + model.getMoney() + " ฿");
                txmon.setTextColor(Color.RED);
            } else if (model.type.equals("Transfer")){
                txmon.setText(model.getMoney() + " ฿");
                txmon.setTextColor(Color.BLUE);
            }

        return convertView;
    }

    @Override
    public int getCount() {
        return this.arrayList.size();
    }
}
